const LoginCom = ( {onChange, password, username} ) => {
    return (<>
    <input type="text" name="id" value={username} onChange={onChange} /><br></br>
    <input type="text" name="pwd" value={password} onChange={onChange} /><br></br>
    </>)
}
export default LoginCom