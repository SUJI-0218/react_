const RegCom = (onChange, username, password, name, addr) => {
    return (<>
    <input type="text" name="id" value={username} onChange={onChange} /><br />
    <input type="text" name="pwd" value={password} onChange={onChange} /><br />
    <input type="text" name="name" value={name} onChange={onChange} /><br />
    <input type="text" name="addr" value={addr} onChange={onChange} /><br />

</>)}
export default RegCom