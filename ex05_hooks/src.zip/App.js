import logo from './logo.svg';
import './App.css';
import ReducerCom from './components/ReducerCom';
import { Routes, Route } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import RegPage from './pages/RegPage';
import ListPage from './pages/ListPage';

function App() {
  return (
    <>
    <Routes>
      <Route path='/login' element={<LoginPage />}></Route>
      <Route path='/register' element={<RegPage />}></Route>
      <Route path='/list' element={<ListPage />}></Route>
    </Routes>
    </>
  );
}

export default App;
