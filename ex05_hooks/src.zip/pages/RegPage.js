import RegCon from "../containers/RegCon"
import HeaderCon from "../containers/HeaderCon"
const RegPage = () => {
    return (<>
    <HeaderCon />
    <RegCon /></>)
}
export default RegPage