import HeaderCon from "../containers/HeaderCon"
import LoginCon from "../containers/LoginCon"
const LoginPage = () => {
    return (<>
    <HeaderCon />
    <LoginCon /></>)
}
export default LoginPage