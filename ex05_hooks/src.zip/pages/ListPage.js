import HeaderCon from "../containers/HeaderCon"
import ListCon from "../containers/ListCon"
const ListPage = () => {
    return ( <>
    <HeaderCon />

    <ListCon /></>)
}
export default ListPage