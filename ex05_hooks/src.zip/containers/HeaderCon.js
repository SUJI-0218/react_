import HeaderCom from "../components/HeaderCom"
const HeaderCon = () => {
    return (<><HeaderCom /></>)
}
export default HeaderCon