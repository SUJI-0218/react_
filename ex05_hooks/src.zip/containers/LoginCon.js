import { useReducer, useState } from "react"
import LoginCom from "../components/LoginCom"
import { initalState, reducer } from "../moduls/member_red"
const LoginCon = () => {
    // const [inputId, setInputId] = useState
    const [state, dispatch] = useReducer(reducer, initalState)
    console.log("login con state : ", state)
    const onChange = (e) => { //e는 event
        console.log("e.target : ", e.target)
        const { value, name } = e.target //key와 value를 같이 쓰면 하나만 쓰면 되는데 달리쓰면 name처럼 써주면 됨
        dispatch({type:"CHANGE_INPUT", value, name, form : "login"})
    }
    return (<><LoginCom 
        username={state.login.id}
        password={state.login.pwd}
        onChange={onChange} /></>)
}
export default LoginCon