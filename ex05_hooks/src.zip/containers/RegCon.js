import { useReducer } from "react"
import RegCom from "../components/RegCom"
import { initalState, reducer } from "../moduls/member_red"
const RegCon = () => {
    const [state, dispatch] = useReducer(reducer, initalState)
    const onChange = (e) => {
        const {value, name } = e.target
        dispatch({type:"CHANGE_INPUT", value, name, form: "register"})
    }
    return (<><RegCom 
        onChange={onChange} 
        username={state.register.id}
        password={state.register.pwd} 
        name={state.register.name} 
        addr={state.register.addr}
         /></>)
}
export default RegCon